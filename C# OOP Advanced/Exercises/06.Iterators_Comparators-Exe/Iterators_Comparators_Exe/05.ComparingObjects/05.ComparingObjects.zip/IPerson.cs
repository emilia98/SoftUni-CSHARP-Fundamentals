﻿namespace _05.ComparingObjects
{
    public interface IPerson
    {
        string Name { get; }

        int Age { get; }

        string Town { get; }
    }
}
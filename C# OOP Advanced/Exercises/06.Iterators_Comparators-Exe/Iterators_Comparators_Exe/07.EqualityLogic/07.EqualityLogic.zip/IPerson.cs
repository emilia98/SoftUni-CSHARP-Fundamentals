﻿namespace _07.EqualityLogic
{
    public interface IPerson
    {
        string Name { get; }

        int Age { get; }
    }
}
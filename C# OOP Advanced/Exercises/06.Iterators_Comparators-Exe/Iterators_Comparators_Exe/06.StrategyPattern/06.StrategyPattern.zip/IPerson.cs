﻿using System.Collections.Generic;

namespace _06.StrategyPattern
{
    public interface IPerson
    {
        string Name { get; }

        int Age { get; }
    }
}
﻿namespace Travel.Entities.Items
{
	public class CellPhone : Item
	{
        // CellPhone – $700 value
        private const int CellPhoneValue = 700;

        public CellPhone() : base(CellPhoneValue)
        {
        }
	}
}
﻿namespace Travel.Entities.Items
{
    public class TravelKit : Item
    {
        // TravelKit – $30 value
        private static int TravelKitValue = 30;

        public TravelKit() : base(TravelKitValue)
        {
        }
    }
}
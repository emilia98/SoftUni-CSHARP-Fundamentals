﻿namespace FestivalManager.Entities.Instruments
{
	public class Drums : Instrument
	{
		protected override int RepairAmount => 20;
	}
}

﻿//namespace Avatar
//{
    public interface IMonument
    {
        string Name { get; }
    }
//}
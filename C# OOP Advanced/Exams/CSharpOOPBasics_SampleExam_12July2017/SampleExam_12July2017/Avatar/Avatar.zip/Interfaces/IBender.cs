﻿//namespace Avatar
//{
    public interface IBender
    {
        string Name { get; }

        int Power { get; }
    }
//}
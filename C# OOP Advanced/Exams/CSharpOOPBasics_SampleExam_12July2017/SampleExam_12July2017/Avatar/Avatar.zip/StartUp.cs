﻿using System;

//namespace Avatar
//{
    public class StartUp
    {
        static void Main()
        {
        }
    }
//}

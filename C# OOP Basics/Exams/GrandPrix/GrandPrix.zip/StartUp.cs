﻿using System;

namespace GrandPrix
{
    public class StartUp
    {
        static void Main()
        {
           /* var tyre = new UltrasoftTyre(250);

            Console.WriteLine(tyre.Name);
            Console.WriteLine(tyre.Hardness);
            Console.WriteLine(tyre.Degradation);
            Console.WriteLine();
            //tyre.Degradation = 45;*/
        }
    }
}

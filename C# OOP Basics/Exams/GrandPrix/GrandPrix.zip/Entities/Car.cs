﻿using System;
using System.Collections.Generic;
using System.Text;

//namespace GrandPrix
//{
    public class Car
    {
        //TODO: Private setters
        //TODO: Constructor
        private int hp;
        private double fuelAmount;
        private Tyre tyre;

        public int Hp
        {
            get { return this.hp; }
            private set { this.hp = value; }
        }

        public double FuelAmount
        {
            get { return this.fuelAmount; }
            private set
            {
                if(value < 0)
                {
                    throw new ArgumentException("The Fuel Amount cannot be a negative number!");
                }

                if(value >= 160)
                {
                    this.fuelAmount = 160;
                }
                else
                {
                    this.fuelAmount = value;
                }
            }
        }

        public Tyre Tyre
        {
            get { return this.tyre; }
            private set
            {
                this.tyre = value;
            }
        }

        public Car(int hp, double fuelAmount, Tyre tyre)
        {
            this.Hp = hp;
            this.FuelAmount = fuelAmount;
            this.Tyre = tyre;
        }
    }
//}
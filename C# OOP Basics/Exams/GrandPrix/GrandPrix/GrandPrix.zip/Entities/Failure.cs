﻿//namespace GrandPrix
//{
    public class Failure
    {
        public string Type { get; }

        public Failure(string type)
        {
            this.Type = type;
        }
    }
//}
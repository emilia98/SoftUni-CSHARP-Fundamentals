namespace SoftUniRestaurant.IO
{
    public interface IReader
    {
        string readData();
    }
}
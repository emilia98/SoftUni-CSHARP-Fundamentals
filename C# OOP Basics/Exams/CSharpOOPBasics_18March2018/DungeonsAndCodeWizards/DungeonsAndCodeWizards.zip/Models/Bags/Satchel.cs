﻿namespace DungeonsAndCodeWizards.Models.Bags
{
    public class Satchel : Bag
    {
        private static int capacity = 20;

        public Satchel() : base(capacity)
        {
        }
    }
}
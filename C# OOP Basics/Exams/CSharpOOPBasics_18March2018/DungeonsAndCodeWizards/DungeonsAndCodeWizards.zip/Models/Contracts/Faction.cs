﻿namespace DungeonsAndCodeWizards.Models.Contracts
{
    public enum Faction
    {
        CSharp,
        Java
    }
}
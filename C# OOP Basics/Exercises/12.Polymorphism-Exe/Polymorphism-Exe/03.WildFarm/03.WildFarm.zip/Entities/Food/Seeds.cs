﻿namespace _03.WildFarm
{
    public class Seeds : Food
    {
        public Seeds(int quantity) : base(quantity)
        {
        }
    }
}
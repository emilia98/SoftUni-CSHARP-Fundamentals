﻿namespace _03.OldestFamilyMember_3
{
    class Person
    {
        public string Name { get; set; }
        public int Age { get; set; }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _07.FoodShortage
{
    public interface IMember
    {
        string Name { get; }

        int Age { get; }
    }
}

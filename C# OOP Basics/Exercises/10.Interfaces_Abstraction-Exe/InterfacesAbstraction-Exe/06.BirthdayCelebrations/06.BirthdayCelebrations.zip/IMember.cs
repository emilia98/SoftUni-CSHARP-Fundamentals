﻿namespace _06.BirthdayCelebrations
{
    public interface IMember
    {
        string Id { get; }
    }
}
﻿namespace _04.Telephony
{
    public interface IBrowseable
    {
        void Browse(string url);
    }
}
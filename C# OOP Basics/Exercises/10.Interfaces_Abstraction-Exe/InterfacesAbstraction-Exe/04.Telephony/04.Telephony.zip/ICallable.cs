﻿namespace _04.Telephony
{
    public interface ICallable
    {
        void Call(string number);
    }
}
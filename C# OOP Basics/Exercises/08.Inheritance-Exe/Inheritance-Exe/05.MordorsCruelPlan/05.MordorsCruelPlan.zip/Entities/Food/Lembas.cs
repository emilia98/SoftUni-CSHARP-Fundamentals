﻿namespace MordorsCruelPlan.Entities
{
    public class Lembas : Food
    {
        private static new int Happiness = 3;

        public Lembas() : base(Lembas.Happiness)
        {
        }
    }
}
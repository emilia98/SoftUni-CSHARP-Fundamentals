﻿namespace MordorsCruelPlan.Entities
{
    public class Sad : Mood
    {
        private static string Mood = "Sad";

        public Sad() : base(Sad.Mood)
        {
        }
    }
}
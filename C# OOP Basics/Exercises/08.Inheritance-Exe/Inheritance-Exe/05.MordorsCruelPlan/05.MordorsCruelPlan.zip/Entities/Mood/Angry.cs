﻿namespace MordorsCruelPlan.Entities
{
    public class Angry : Mood
    {
        private static string Mood = "Angry";

        public Angry() : base(Angry.Mood)
        {
        }
    }
}
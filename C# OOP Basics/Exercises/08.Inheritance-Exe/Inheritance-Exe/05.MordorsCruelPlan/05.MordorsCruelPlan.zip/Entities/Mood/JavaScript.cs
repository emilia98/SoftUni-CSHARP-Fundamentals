﻿namespace MordorsCruelPlan.Entities
{
    public class JavaScript : Mood
    {
        private static string Mood = "JavaScript";

        public JavaScript() : base(JavaScript.Mood)
        {
        }
    }
}
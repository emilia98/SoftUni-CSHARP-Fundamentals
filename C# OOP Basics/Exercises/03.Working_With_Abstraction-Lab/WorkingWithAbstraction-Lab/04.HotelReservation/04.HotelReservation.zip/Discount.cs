﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _04.HotelReservation
{
    public enum Discount
    {
        VIP = 20,
        SecondVisit = 10,
        None = 0
    }
}

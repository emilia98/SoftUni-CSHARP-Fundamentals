﻿namespace HotelReservation_2
{
    public enum Discount
    {
        VIP = 20,
        SecondVisit = 10,
        None = 0
    }
}
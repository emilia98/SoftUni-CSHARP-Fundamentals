﻿using System;
using System.Collections.Generic;
using System.Text;


public class Rectangle
{
    public string id;
    public double width;
    public double height;
    public double y;
    public double x;
}

